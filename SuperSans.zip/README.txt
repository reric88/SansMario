These are just reskins of the "Super Mario Bros" Mario sprites. I have not modified anything else but the 4 "main" marios (small, big, fire, weird.)

To use these files, I will be referring to Luma for the 3ds.

1. Setup Luma3DS if you haven't done so and enable game patching. Check 3ds.hacks.guide if you need help.

2. (a) Inside your luma folder on your SD card, navigate to or create this file path: luma/titles/TITLE-ID/romfs

2. (b) TITLE-ID will be replaced with the correct ID of your title, they are below.

JP: 00040000001A0300
US: 00040000001A0400
EU: 00040000001A0500

For instance, my path would be: luma/titles/00040000001A0400/romfs

3. Paste the contents of the archive into the romfs folder on your sd card. From this archive it should only be the Model folder.

4. That's it, get dunked on!